package ruken.yunis;

public class Player {

	private String name;
	private boolean isTurn;
	private CellTeam team;
	
	public Player(String name, CellTeam team) {
		this.name = name;
		this.team = team;
		if (team == CellTeam.Player1) {
			isTurn = true;
		} else {
			isTurn = false;
		}
	}
	
	public void switchTurn() {
		isTurn = !isTurn;
	}
	
	public boolean isTurn() {
		return isTurn;
	}
	
	public String getName() {
		return name;
	}
	
	public CellTeam getTeam() {
		return team;
	}
	
	

}
