package ruken.yunis;

public class Board {

		
	private Cell[][] board;
	private CellTeam state;
	
	public Board() {
		board = new Cell[6][7];
		for (int i = 0; i < 6; i++) {
			for (int j = 0; j < 7; j++) {
				board[i][j] = new Cell(CellTeam.none);
			}
		}
		state = CellTeam.none;
	}
	
	public Cell[][] getBoard() {
		return board;
	}
	
	public CellTeam getState() {
		return state;
	}
 	
	public void move(int col, Player player) {
		if (player.isTurn()) {
			int height = colHeight(col);
			if (height < 6 && board[height][col].getTeam().equals(CellTeam.none)) {
				board[height][col] = new Cell(player.getTeam());
			} else {
				System.out.println("Collumn is full, please choose a different collumn.");
				player.switchTurn();

			}
			CellTeam gameState = isOver();
			if (gameState.equals(CellTeam.Player1) || gameState.equals(CellTeam.Player2)) {
				state = gameState;
			}	

		}
		player.switchTurn();
	}
	
	private int colHeight(int col) {
		for (int i = 0; i < 6; i++) {
			if (board[i][col].getTeam().equals(CellTeam.none)) {
				return i;
			}
		}
		return 5;
	}
	
	public CellTeam isOver() {
		int count1 = 0;
		int count2 = 0;
		//possible move left
		boolean moveLeft = false;
		for (int i = 0; i < 6; i++) {
			for (int j = 0; j < 7; j++) {
				if (board[i][j].getTeam().equals(CellTeam.none)) {
					moveLeft = true;
					break;
				}
			}
			if (moveLeft) {
				break;
			}
		}
		if (!moveLeft) {
			return CellTeam.Tie;
		}
		//horizontal
		for (int i = 0; i < 6; i++) {
			for (int j = 0; j < 7; j++) {
				if (count1 >= 4) {
					return CellTeam.Player1;
				}
				if (count2 >= 4) {
					return CellTeam.Player2;
				}
				if (board[i][j].getTeam().equals(CellTeam.Player1)) {
					count1++;
					count2 = 0;
				} else if (board[i][j].getTeam().equals(CellTeam.Player2)) {
					count1 = 0;
					count2++;
				} else {
					count1 = 0;
					count2 = 0;
				}
			}
		}
		//vertical
		for (int j = 0; j < 7; j++) {
			for (int i = 0; i < 6; i++) {
				if (count1 >= 4) {
					return CellTeam.Player1;
				}
				if (count2 >= 4) {
					return CellTeam.Player2;
				}
				if (board[i][j].getTeam().equals(CellTeam.Player1)) {
					count1++;
					count2 = 0;
				} else if (board[i][j].getTeam().equals(CellTeam.Player2)) {
					count1 = 0;
					count2++;
				} else {
					count1 = 0;
					count2 = 0;
				}
			}
		}
		
		//diagonal bottom right - top left
		for (int i = 0; i < 6; i++) {
			for (int j = 0; j < 7; j++) {
				//TODO
			}
		}
		//diagonal bottom left = top right
		for (int i = 0; i < 6; i++) {
			for (int j = 0; j < 7; j++) {
				//TODO
			}
		}
		return CellTeam.none;
		
	}
	
	

}
