package ruken.yunis;

public enum CellTeam {
	
	Player1, Player2, none, Tie;
	
}
