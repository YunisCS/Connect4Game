package ruken.yunis;

public class Board {

		
	private Cell[][] board;
	private CellTeam state;
	
	public Board() {
		board = new Cell[6][7];
		for (int i = 0; i < 6; i++) {
			for (int j = 0; j < 7; j++) {
				board[i][j] = new Cell(CellTeam.none);
			}
		}
		state = CellTeam.none;
	}
	
	public Cell[][] getBoard() {
		return board;
	}
	
	public CellTeam getState() {
		return state;
	}
 	
	public void move(int col, Player player) {
		if (player.isTurn()) {
			int height = colHeight(col);
			if (height < 6 && board[height][col].getTeam().equals(CellTeam.none)) {
				board[height][col] = new Cell(player.getTeam());
			} else {
				System.out.println("Collumn is full, please choose a different column.");
				player.switchTurn();

			}
			CellTeam gameState = isOver();
			if (gameState.equals(CellTeam.Player1) || gameState.equals(CellTeam.Player2) || gameState.equals(CellTeam.Tie)) {
				state = gameState;
			}	

		}
		player.switchTurn();
	}
	
	private int colHeight(int col) {
		for (int i = 0; i < 6; i++) {
			if (board[i][col].getTeam().equals(CellTeam.none)) {
				return i;
			}
		}
		return 5;
	}
	
	public CellTeam isOver() {
		int count1 = 0;
		int count2 = 0;

		//horizontal
		for (int i = 0; i < 6; i++) {
			count1 = 0;
			count2 = 0;
			for (int j = 0; j < 7; j++) {

				if (board[i][j].getTeam().equals(CellTeam.Player1)) {
					count1++;
					count2 = 0;
				} else if (board[i][j].getTeam().equals(CellTeam.Player2)) {
					count1 = 0;
					count2++;
				} else {
					count1 = 0;
					count2 = 0;
				}
				if (count1 >= 4) {
					return CellTeam.Player1;
				}
				if (count2 >= 4) {
					return CellTeam.Player2;
				}
			}
		}
		//vertical
		for (int j = 0; j < 7; j++) {
			count1 = 0;
			count2 = 0;
			for (int i = 0; i < 6; i++) {
				if (board[i][j].getTeam().equals(CellTeam.Player1)) {
					count1++;
					count2 = 0;
				} else if (board[i][j].getTeam().equals(CellTeam.Player2)) {
					count1 = 0;
					count2++;
				} else {
					count1 = 0;
					count2 = 0;
				}
				if (count1 >= 4) {
					return CellTeam.Player1;
				}
				if (count2 >= 4) {
					return CellTeam.Player2;
				}
			}
			
		}
		
		//diagonal top right - bottom left
		for (int colStart = 3; colStart < 7; colStart++) {
			int row; int col;
			count1 = 0;
			count2 = 0;
			for (row = 5, col = colStart; row >= 0 && col >= 0; col--, row--) {
				if (board[row][col].getTeam().equals(CellTeam.Player1)) {
					count1++;
					count2 = 0;
				} else if (board[row][col].getTeam().equals(CellTeam.Player2)) {
					count1 = 0;
					count2++;
				} else {
					count1 = 0;
					count2 = 0;
				}
				if (count1 >= 4) {
					return CellTeam.Player1;
				}
				if (count2 >= 4) {
					return CellTeam.Player2;
				}
			}
		}
		for (int rowStart = 3; rowStart < 5; rowStart++) {
			int row; int col;
			count1 = 0;
			count2 = 0;
			for (row = rowStart, col = 6; row >= 0 && col >= 0; row--, col--) {
				if (board[row][col].getTeam().equals(CellTeam.Player1)) {
					count1++;
					count2 = 0;
				} else if (board[row][col].getTeam().equals(CellTeam.Player2)) {
					count1 = 0;
					count2++;
				} else {
					count1 = 0;
					count2 = 0;
				}
				if (count1 >= 4) {
					return CellTeam.Player1;
				}
				if (count2 >= 4) {
					return CellTeam.Player2;
				}
			}
		}
		//diagonal top left - bottom right
		for (int rowStart = 5; rowStart >= 3; rowStart--) {
			int row; int col;
			count1 = 0;
			count2 = 0;
			for (row = rowStart, col = 0; row >= 0 && col < 7; row--, col++) {
				if (board[row][col].getTeam().equals(CellTeam.Player1)) {
					count1++;
					count2 = 0;
				} else if (board[row][col].getTeam().equals(CellTeam.Player2)) {
					count1 = 0;
					count2++;
				} else {
					count1 = 0;
					count2 = 0;
				}
				if (count1 >= 4) {
					return CellTeam.Player1;
				}
				if (count2 >= 4) {
					return CellTeam.Player2;
				}
			}
		}
		for (int colStart = 1; colStart < 4; colStart++) {
			int row; int col;
			count1 = 0;
			count2 = 0;
			for (row = 5, col = colStart; row >= 0 && col < 7; row--, col++) {
				if (board[row][col].getTeam().equals(CellTeam.Player1)) {
					count1++;
					count2 = 0;
				} else if (board[row][col].getTeam().equals(CellTeam.Player2)) {
					count1 = 0;
					count2++;
				} else {
					count1 = 0;
					count2 = 0;
				}
				if (count1 >= 4) {
					return CellTeam.Player1;
				}
				if (count2 >= 4) {
					return CellTeam.Player2;
				}
			}
		}
		
		//possible move left
		boolean moveLeft = false;
		for (int i = 0; i < 6; i++) {
			for (int j = 0; j < 7; j++) {
				if (board[i][j].getTeam().equals(CellTeam.none)) {
					moveLeft = true;
					break;
				}
			}
			if (moveLeft) {
				break;
			}
		}
		if (!moveLeft) {
			return CellTeam.Tie;
		}
		return CellTeam.none;
		
	}
	
	

}
