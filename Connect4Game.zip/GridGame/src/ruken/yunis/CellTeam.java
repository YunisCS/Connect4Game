package ruken.yunis;

public enum CellTeam {
	
	Player1, Player2, none, Tie;
	
	public String toString() {
		switch (this) {
			
		case Player1: return "player1";
		case Player2: return "player2";
		case none: return "none";
		case Tie: return "tie";
		}
		return "none";
	}
	
}
