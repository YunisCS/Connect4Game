package ruken.yunis;

public class Cell {
	
	private CellTeam team;
	
	public Cell(CellTeam team) {
		this.team = team;
	}
	
	public Cell(int team) {
		if (team == 1) {
			this.team = CellTeam.Player1;
		} else if (team == 2) {
			this.team = CellTeam.Player2;
		} else {
			this.team = CellTeam.none;
		}
	}
	
	public CellTeam getTeam() {
		return team;
	}
	
	public void setTeam(CellTeam team) {
		this.team = team;
	}
	
	public String toString() {
		if (team.equals(CellTeam.Player1)) {
			return "O";
		} else if (team.equals(CellTeam.Player2)) {
			return "X";
		}
		return "-";
	}
}
