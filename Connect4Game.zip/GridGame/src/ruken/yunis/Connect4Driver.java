package ruken.yunis;

import java.util.Scanner;
import javafx.application.*;
import javafx.scene.*;
import javafx.scene.control.Button;
import javafx.scene.layout.StackPane;
import javafx.stage.*;


public class Connect4Driver extends Application{

	public static void main(String[] args) {
		
		Scanner in = new Scanner(System.in);
		//launch(args);
		System.out.print("Player 1 Name: ");
		Player player1 = new Player(in.nextLine(), CellTeam.Player1);
		System.out.print("Player 2 Name: ");
		Player player2 = new Player(in.nextLine(), CellTeam.Player2);
		
		Board game = new Board();
		while (game.getState().equals(CellTeam.none)) {
			if (player1.isTurn()) {
				while(player1.isTurn()) {

					int col = robustInt(in, player1.getName() + ", which column would you like to move in? (1 - 7)") - 1;
					game.move(col, player1);
				}
				player2.switchTurn();
				
			} else {
				while (player2.isTurn()) {

					int col = robustInt(in, player2.getName() + ", which column would you like to move in? (1 - 7)") - 1;
					game.move(col, player2);
				}
				player1.switchTurn();
			}
			for (int i = 5; i >= 0; i--) {
				String row = "";
				for (int j = 0; j < 7; j++) {
					row += game.getBoard()[i][j].toString() + " ";
				}
				System.out.println(row);
			}
		}
		if (game.getState().equals(CellTeam.Player1)) {
			System.out.println("Congratulations " + player1.getName() + ". You win!");
		} else if (game.getState().equals(CellTeam.Player2)) {
			System.out.println("Congratulations " + player2.getName() + ". You win!");
		} else {
			System.out.println("Wow you both suck. Its a tie I guess.");
		}
		
		
	}
	
	private static int robustInt(Scanner in, String prompt) {
		System.out.print(prompt + ": ");
		int n;
		while(!in.hasNextInt()) {
			System.out.print("Invalid input. " + prompt + ": ");
			in.next();
			in.nextLine();
		}
		n = in.nextInt();
		if (n > 7 || n < 1) {
			return robustInt(in, prompt);
		}
		
		return n;
	}
	@Override
	public void start(Stage primaryStage) throws Exception {
		primaryStage.setTitle("Connect 4");
		Button button = new Button();
		StackPane layout = new StackPane();
		layout.getChildren().add(button);
		
		Scene scene = new Scene(layout, 300, 250);
		primaryStage.setScene(scene);
		primaryStage.show();
		
	}

}
